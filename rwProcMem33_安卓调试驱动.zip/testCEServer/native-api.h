#pragma once
#define MAX_HIT_COUNT 5000000